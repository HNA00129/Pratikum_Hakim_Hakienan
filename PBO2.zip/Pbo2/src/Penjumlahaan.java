/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author a
 */
public class Penjumlahaan {
    public static void main (String[] args) {
        int NilaiA = 1500;
        int NilaiB = 75;
        int Jumlah = NilaiA + NilaiB;
            // Lengkapilah kode pada baris ini
        System.out.println("NilaiA = "+ NilaiA);
        System.out.println("NilaiB = "+ NilaiB);
        System.out.println("Jumlah = "+ Jumlah);
    }
}
