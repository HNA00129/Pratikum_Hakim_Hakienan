/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author a
 */
public class Salam2 {
    public static void main(String[] args){
        //Buat Karakter
        String c1 = "S";
        String c2 = "A";
        String c3 = "L";
        String c4 = "A";
        String c5 = "M";
        //Print
        System.out.println(c1+c2+c3+c4+c5);
        System.out.println(c5+c4+c3+c2+c1);
    }
}