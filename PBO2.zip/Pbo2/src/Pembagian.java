/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author a
 */
public class Pembagian {
     public static void main (String[] args) {
        int A = 20;
        int B = 8;
        float hasilBagi = (float) A / B;
            // Lengkapilah kode pada baris ini
        System.out.println("A = "+ A);
        System.out.println("B = "+ B);
        System.out.println("A dibagian B = "+ hasilBagi);
    }
}

