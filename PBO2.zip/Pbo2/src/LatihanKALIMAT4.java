/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author a
 */
public class LatihanKALIMAT4 {
    public static void main(String[] args){
        //Buat Variabel
        String subjek       = " Saya";
        String prediket     = " Menulis";
        String objek        = " Program Java";
        String keterangan   = " Hari ini";
        // Print kalimat S+P+O+K
        System.out.println(subjek + prediket+objek + keterangan);      
    }
    
}
