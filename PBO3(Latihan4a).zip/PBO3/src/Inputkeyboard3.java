
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ASUS
 */
public class Inputkeyboard3 {
    public static void main(String[] args){
        
        int nilai1 = Integer.parseInt(JOptionPane.showInputDialog("Input angka pertama"));
        int nilai2 = Integer.parseInt(JOptionPane.showInputDialog("Input angka kedua"));
        
        int h1 =(nilai1 + nilai2) * (nilai2 + nilai1);
        int h2 =(nilai1 % 4) * nilai2;
        
        System.out.println("Hasil penjumlahan pertama = "+h1);
        System.out.println("Hasil penjumlahan kedua = "+h2);
    }
}