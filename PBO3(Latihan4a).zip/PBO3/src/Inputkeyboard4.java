
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ASUS
 */
public class Inputkeyboard4 {
    public static void main(String[] args){
        
        int nilai1 = Integer.parseInt(JOptionPane.showInputDialog("Input angka pertama"));
        int nilai2 = Integer.parseInt(JOptionPane.showInputDialog("Input angka kedua"));
        
        int h1 =(nilai1 + nilai2) * (nilai2 + nilai1);
        int h2 =(nilai1 % 4) * nilai2;
        
        boolean b1 = h1 >= h2;
        boolean b2 = h2 >= h1;
        boolean b3 = (h1 % 4) == (++h2 % 5);
        boolean b4 = (b1 ^ b3) && (b2 || b3);
        boolean b5 = b2 || (b3 &&(b2 ^ b1));
        
        System.out.println("Boolean pertama = "+b1);
        System.out.println("Boolean kedua = "+b2);
        System.out.println("Boolean ketiga = "+b3);
        System.out.println("Boolean keempat = "+b4);
        System.out.println("Boolean kelima = "+b5);
    }
}
