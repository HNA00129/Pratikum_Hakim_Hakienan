/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Scanner;
/**
 *
 * @author ASUS
 */
public class Kelulusan1 {
    public static void main(String[] args) {
        // Buat Scanner
        Scanner inp = new Scanner(System.in);
        // Ambil Nama
        System.out.print("Masukkan nama anda = ");
        String Nama = inp.next();

        // Ambil NIM
        System.out.print("Masukkan  NIM = ");
        String nim = inp.next();

        // Ambil Nilai
        System.out.print("Masukkan Nilai = ");
        int nilai = inp.nextInt();
        // print
        if(nilai > 60) {
             System.out.println("Anda lulus");
        }else {
             System.out.println("Anda tidak lulus");
        }
    }
}
