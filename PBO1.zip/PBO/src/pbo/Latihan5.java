/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbo;

import java.util.Scanner;

/**
 *
 * @author a
 */
public class Latihan5 {
    public static void main(String[] args){
        String nama;
        Scanner inputan = new Scanner(System.in).useDelimiter("\n");
        System.out.print("Masukkan Nama Lengkap Anda :");
        nama = inputan.next();
        System.out.print("Halo..."+nama+" Selamat Belajar Java");
        
    }
    
}
