/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbo;

import java.util.Scanner;

/**
 *
 * @author a
 */
public class Data_mahasiswa { 
    public static void main(String[] args){
        String Nama;
        String Program_Studi;
        String Nama_Kampus;
        Scanner input = new Scanner(System.in);
        
        System.out.print("Nama Mahasiswa    :");
        Nama = input.nextLine();
        
        System.out.print("Program Studi     :");
        Program_Studi = input.nextLine();
        
        System.out.print("Nama Kampus       :");
        Nama_Kampus = input.nextLine();
        
    }   
}
